import * as assert from "assert";
import {evalParse4} from './L4-eval-box';
import { parseL3 } from "./L3-ast";
import { parseL4 } from "./L4-ast";

assert.deepEqual(evalParse4(`
(L4 (define loop (lambda (x) (loop x)))
    ((lambda ((f lazy)) 1) (loop 0)))`),
    1);
assert.deepEqual(evalParse4(`
    (L4 (if ((lambda ((x lazy)) (= x 10)) 10) #t #f))`),
        true);


assert.deepEqual(evalParse4(`
(L4 ((lambda ((x lazy) y) (= y 10)) (/ 2) 10))`),
    true);